export default function Marks(){
    return <h1>Marks</h1>
}