import { BrowserRouter, Routes, Route } from 'react-router-dom';

import React, { Suspense } from 'react';

const AdminSignIn = React.lazy(() => import('./pages/AdminSignIn'))
const TacherSignIn = React.lazy(() => import('./pages/TacherSignIn'))
const Profile = React.lazy(() => import('./pages/Profile'))
const Header = React.lazy(() => import('./components/Header'))
const PrivateRoute = React.lazy(() => import('./components/PrivateRoute'))
import Dashboard from './pages/Dashboard'
import Addmission from './pages/Addmission';
import Loader from './components/Loader'
import Marks from './pages/Marks';
export default function App() {
  return (
    <BrowserRouter>
      <Suspense fallback={<Loader />}>
        <Header />
        <Routes>
          <Route path='/admin' element={<AdminSignIn />} />
          <Route path='/addmission' element={<Addmission />} />
          <Route path='/marks' element={<Marks />} />
          <Route path='/' element={<TacherSignIn />} />
          <Route element={<PrivateRoute />}>
            <Route path='/profile' element={<Profile />} />
            <Route path='/dashboard' element={<Dashboard />} />
          </Route>
        </Routes>
      </Suspense>
    </BrowserRouter>
  );
}
